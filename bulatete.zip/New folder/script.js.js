var n2 = "";
var sign = "";

function (){
	document.getElementById ("display").value = "";
}
function addition () {
document.getElementById ("display").value = "";
document.getElementById ("display").value = ""; sign = "+";

}

function subtraction () {
document.getElementById ("display").value = "";
document.getElementById ("display").value = ""; sign = "-";

}

function multiply () {
document.getElementById ("display").value = "";
document.getElementById ("display").value = ""; sign = "*";

}

function divide () {
document.getElementById ("display").value = "";
document.getElementById ("display").value = ""; sign = "/";

}


function one () {
document.getElementById ("display").value = "";
document.getElementById ("display").value = ""; sign = "1";

}

function two () {
document.getElementById ("display").value = "";
document.getElementById ("display").value = ""; sign = "2";

}

function three () {
document.getElementById ("display").value = "";
document.getElementById ("display").value = ""; sign = "3";

}

function four () {
document.getElementById ("display").value = "";
document.getElementById ("display").value = ""; sign = "4";

}

function five () {
document.getElementById ("display").value = "";
document.getElementById ("display").value = ""; sign = "5";

}

function six () {
document.getElementById ("display").value = "";
document.getElementById ("display").value = ""; sign = "6";

}

function seven () {
document.getElementById ("display").value = "";
document.getElementById ("display").value = ""; sign = "7";

}

function eight () {
document.getElementById ("display").value = "";
document.getElementById ("display").value = ""; sign = "8";

}

function nine () {
document.getElementById ("display").value = "";
document.getElementById ("display").value = ""; sign = "9";

}function zero () {
document.getElementById ("display").value = "";
document.getElementById ("display").value = ""; sign = "0";

}


function equals(){
	let n1 = document.getElementById("display").value;
	if (sign == "+"){
		document.getElementById("display").value = math.round((ParseFloat(n1)+ ParseFloat(n2)) * 100/100;
		sign ="";			

document.getElementById("display").value = math.round((ParseFloat(n2)))

	}
}









